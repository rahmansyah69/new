# TokenBesar Bot

in this project, there are 2 tools.



**generateemail/** in this folder there are two tools : 

first tools are new_big.js this tool is for auto register and auto verification account. Email Host: generate.email

second tools are auto_veryf.js if first tools failed to get inbox from the email the result link saved to result_url.txt then  auto_veryf.js verify URL from result_url.txt 

**dottrick/** in this folder there are three tools : 

first tools are regist_gmail.js this for auto register with gmail and auto dottrick generator

second tools grab_gmail.js after register with regist_gmail.js u can use grab_gmail.js for get link

third tools aut_link.js after u get link with grab_gmail.js u can verify your account with this tools


# this tools require api key :D

where we can get  api key ? :D privacy /pm me




## Installation


```terminal
$ git clone this project
$ cd folderproject/
$ npm install
```

## Usage

```node
$ node script.js
```


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)